{{- define "opencrane.obot.rbac" -}}
{{- if and .Values.mcpGateway.enabled (ne (include "opencrane.mcpGatewayShared" .) "true") }}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ include "opencrane.fullname" . }}-mcp-gateway
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "opencrane.labels" . | nindent 4 }}
    app.kubernetes.io/component: mcp-gateway
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ include "opencrane.fullname" . }}-mcp-gateway
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "opencrane.labels" . | nindent 4 }}
    app.kubernetes.io/component: mcp-gateway
rules:
  # Obot needs to manage pods, services, PVCs, configmaps, deployments, replicasets, etc.
  # for the MCP servers it dynamically provisions.
  - apiGroups: [""]
    resources: ["secrets", "services", "persistentvolumeclaims", "configmaps", "serviceaccounts"]
    verbs: ["create", "get", "list", "watch", "update", "patch", "delete"]
  - apiGroups: [""]
    resources: ["serviceaccounts/token"]
    verbs: ["create"]
  - apiGroups: [""]
    resources: ["pods", "pods/log", "events"]
    verbs: ["create", "get", "list", "watch", "update", "patch", "delete"]
  - apiGroups: ["apps"]
    resources: ["deployments", "replicasets"]
    verbs: ["create", "get", "list", "watch", "update", "patch", "delete"]
  - apiGroups: ["rbac.authorization.k8s.io"]
    resources: ["roles", "rolebindings"]
    verbs: ["create", "get", "list", "watch", "update", "patch", "delete"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ include "opencrane.fullname" . }}-mcp-gateway
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "opencrane.labels" . | nindent 4 }}
    app.kubernetes.io/component: mcp-gateway
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: {{ include "opencrane.fullname" . }}-mcp-gateway
subjects:
  - kind: ServiceAccount
    name: {{ include "opencrane.fullname" . }}-mcp-gateway
    namespace: {{ .Release.Namespace }}
{{- end }}
{{- end }}
