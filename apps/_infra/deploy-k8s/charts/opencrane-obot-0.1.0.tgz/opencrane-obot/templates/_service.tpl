{{- define "opencrane.obot.service" -}}
{{- /* Service only exists for the release-local (instance-scoped) Obot. A shared
       Obot lives outside this release, reached via opencrane.mcpGatewayUrl. */ -}}
{{- if and .Values.mcpGateway.enabled (ne (include "opencrane.mcpGatewayShared" .) "true") }}
apiVersion: v1
kind: Service
metadata:
  name: {{ include "opencrane.fullname" . }}-mcp-gateway
  labels:
    {{- include "opencrane.labels" . | nindent 4 }}
    app.kubernetes.io/component: mcp-gateway
spec:
  type: ClusterIP
  ports:
    - port: {{ .Values.mcpGateway.service.port }}
      targetPort: http
      protocol: TCP
      name: http
  selector:
    {{- include "opencrane.selectorLabels" . | nindent 4 }}
    app.kubernetes.io/component: mcp-gateway
{{- end }}
{{- end }}
